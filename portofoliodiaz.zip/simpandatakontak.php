<?php
// Pastikan Anda memiliki koneksi ke database
$servername = "localhost"; // Ganti dengan nama server database Anda
$username = "root"; // Ganti dengan nama pengguna database Anda
$password = ""; // Ganti dengan kata sandi database Anda
$database = "portofoliodiaz"; // Ganti dengan nama database Anda

// Buat koneksi ke database
$conn = new mysqli($servername, $username, $password, $database);

// Periksa koneksi database
if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}

// Tangkap data dari formulir
$yourname = $_POST['yourname'];
$youremail = $_POST['youremail'];
$yoursubject = $_POST['yoursubject'];
$yourmassage = $_POST['yourmassage'];

// Query untuk menyimpan data ke tabel "tbkontak"
$sql = "INSERT INTO tbmassage (yourname, youremail, yoursubject, yourmassage) VALUES ('$yourname', '$youremail', '$yoursubject', '$yourmassage')";

// Eksekusi query
if ($conn->query($sql) === TRUE) {
    echo "Data berhasil disimpan ke dalam database.";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Tutup koneksi ke database
$conn->close();
?>
